{ DATABASE tercero_ih_grupo_6  delimiter | }

grant dba to "Programacion";











{ TABLE "Programacion".errores row size = 106 number of columns = 3 index size = 9 }

{ unload file name = error00100.unl number of rows = 0 }

create table "Programacion".errores 
  (
    cod_error serial not null ,
    descripcion varchar(50) not null ,
    descripcion_tecnica varchar(50) not null ,
    primary key (cod_error)  constraint "Programacion".pk_coderror
  );

revoke all on "Programacion".errores from "public" as "Programacion";

{ TABLE "Programacion".materia row size = 62 number of columns = 4 index size = 9 }

{ unload file name = mater00101.unl number of rows = 1 }

create table "Programacion".materia 
  (
    cod_materia serial not null ,
    nombre varchar(50) not null ,
    carga_horaria integer not null ,
    baja varchar(2) not null ,
    
    check (baja IN ('si' ,'no' )) constraint "Programacion".ck_bajamateria,
    primary key (cod_materia)  constraint "Programacion".pk_materia
  );

revoke all on "Programacion".materia from "public" as "Programacion";

{ TABLE "Programacion".carrera row size = 58 number of columns = 3 index size = 9 }

{ unload file name = carre00102.unl number of rows = 1 }

create table "Programacion".carrera 
  (
    cod_carrera serial not null ,
    nombre varchar(50) not null ,
    baja varchar(2) not null ,
    
    check (baja IN ('si' ,'no' )) constraint "Programacion".ck_bajacarrera,
    primary key (cod_carrera)  constraint "Programacion".pk_carrera
  );

revoke all on "Programacion".carrera from "public" as "Programacion";

{ TABLE "Programacion".grupo row size = 36 number of columns = 5 index size = 18 }

{ unload file name = grupo00103.unl number of rows = 1 }

create table "Programacion".grupo 
  (
    cod_grupo serial not null ,
    descripcion varchar(20) not null ,
    cod_carrera integer not null ,
    baja varchar(2) not null ,
    cantidad integer,
    
    check (baja IN ('si' ,'no' )) constraint "Programacion".ck_bajagrupo,
    primary key (cod_grupo)  constraint "Programacion".pk_grupo
  );

revoke all on "Programacion".grupo from "public" as "Programacion";

{ TABLE "Programacion".salon row size = 32 number of columns = 4 index size = 9 }

{ unload file name = salon00104.unl number of rows = 1 }

create table "Programacion".salon 
  (
    cod_salon serial not null ,
    descripcion varchar(20) not null ,
    baja varchar(2) not null ,
    capacidad integer,
    
    check (baja IN ('si' ,'no' )) constraint "Programacion".ck_bajasalon,
    primary key (cod_salon)  constraint "Programacion".pk_salon
  );

revoke all on "Programacion".salon from "public" as "Programacion";

{ TABLE "Programacion".turno row size = 28 number of columns = 3 index size = 9 }

{ unload file name = turno00105.unl number of rows = 3 }

create table "Programacion".turno 
  (
    cod_turno serial not null ,
    nombre varchar(20) not null ,
    baja varchar(2) not null ,
    
    check (baja IN ('si' ,'no' )) constraint "Programacion".ck_bajaturno,
    primary key (cod_turno)  constraint "Programacion".pk_turno
  );

revoke all on "Programacion".turno from "public" as "Programacion";

{ TABLE "Programacion".horario row size = 42 number of columns = 7 index size = 18 }

{ unload file name = horar00106.unl number of rows = 1 }

create table "Programacion".horario 
  (
    cod_horario serial not null ,
    cod_turno integer not null ,
    dia varchar(20) not null ,
    numero_hora integer not null ,
    hora_inicio datetime hour to minute not null ,
    hora_fin datetime hour to minute not null ,
    baja varchar(2) not null ,
    
    check (baja IN ('si' ,'no' )) constraint "Programacion".ck_bajahorario,
    primary key (cod_horario)  constraint "Programacion".pk_codhorario
  );

revoke all on "Programacion".horario from "public" as "Programacion";

{ TABLE "Programacion".historial row size = 166 number of columns = 4 index size = 9 }

{ unload file name = histo00108.unl number of rows = 0 }

create table "Programacion".historial 
  (
    cod_historial serial not null ,
    ci integer not null ,
    fecha_hora datetime year to minute not null ,
    descripcion varchar(150),
    primary key (cod_historial)  constraint "Programacion".pk_codhistorial
  );

revoke all on "Programacion".historial from "public" as "Programacion";

{ TABLE "Programacion".dicta row size = 8 number of columns = 2 index size = 22 }

{ unload file name = dicta00109.unl number of rows = 1 }

create table "Programacion".dicta 
  (
    ci integer not null ,
    cod_materia integer not null ,
    primary key (ci,cod_materia) 
  );

revoke all on "Programacion".dicta from "public" as "Programacion";

{ TABLE "Programacion".tiene row size = 12 number of columns = 3 index size = 39 }

{ unload file name = tiene00110.unl number of rows = 0 }

create table "Programacion".tiene 
  (
    ci integer not null ,
    cod_materia integer not null ,
    cod_grupo integer not null ,
    primary key (ci,cod_materia,cod_grupo) 
  );

revoke all on "Programacion".tiene from "public" as "Programacion";

{ TABLE "Programacion".planilla row size = 135 number of columns = 9 index size = 60 }

{ unload file name = plani00111.unl number of rows = 0 }

create table "Programacion".planilla 
  (
    fecha datetime year to minute not null ,
    cod_salon integer not null ,
    cod_horario integer not null ,
    cod_materia integer not null ,
    ci integer not null ,
    cod_grupo integer not null ,
    descripcion varchar(100) not null ,
    version integer not null ,
    baja varchar(2) not null ,
    
    check (baja IN ('si' ,'no' )) constraint "Programacion".ck_planilla,
    primary key (fecha,cod_salon,cod_horario)  constraint "Programacion".pk_plan
  );

revoke all on "Programacion".planilla from "public" as "Programacion";

{ TABLE "Programacion".persona row size = 105 number of columns = 8 index size = 0 }

{ unload file name = perso00112.unl number of rows = 4 }

create table "Programacion".persona 
  (
    ci varchar(9),
    contrasena varchar(20) not null ,
    tipo varchar(20) not null ,
    nombre varchar(20) not null ,
    apellido varchar(20) not null ,
    telefono integer not null ,
    baja varchar(2) not null ,
    celular integer,
    
    check (baja IN ('si' ,'no' )) constraint "Programacion".ck_bajausuario
  );

revoke all on "Programacion".persona from "public" as "Programacion";




grant select on "Programacion".errores to "public" as "Programacion";
grant update on "Programacion".errores to "public" as "Programacion";
grant insert on "Programacion".errores to "public" as "Programacion";
grant delete on "Programacion".errores to "public" as "Programacion";
grant index on "Programacion".errores to "public" as "Programacion";
grant select on "Programacion".materia to "public" as "Programacion";
grant update on "Programacion".materia to "public" as "Programacion";
grant insert on "Programacion".materia to "public" as "Programacion";
grant delete on "Programacion".materia to "public" as "Programacion";
grant index on "Programacion".materia to "public" as "Programacion";
grant select on "Programacion".carrera to "public" as "Programacion";
grant update on "Programacion".carrera to "public" as "Programacion";
grant insert on "Programacion".carrera to "public" as "Programacion";
grant delete on "Programacion".carrera to "public" as "Programacion";
grant index on "Programacion".carrera to "public" as "Programacion";
grant select on "Programacion".grupo to "public" as "Programacion";
grant update on "Programacion".grupo to "public" as "Programacion";
grant insert on "Programacion".grupo to "public" as "Programacion";
grant delete on "Programacion".grupo to "public" as "Programacion";
grant index on "Programacion".grupo to "public" as "Programacion";
grant select on "Programacion".salon to "public" as "Programacion";
grant update on "Programacion".salon to "public" as "Programacion";
grant insert on "Programacion".salon to "public" as "Programacion";
grant delete on "Programacion".salon to "public" as "Programacion";
grant index on "Programacion".salon to "public" as "Programacion";
grant select on "Programacion".turno to "public" as "Programacion";
grant update on "Programacion".turno to "public" as "Programacion";
grant insert on "Programacion".turno to "public" as "Programacion";
grant delete on "Programacion".turno to "public" as "Programacion";
grant index on "Programacion".turno to "public" as "Programacion";
grant select on "Programacion".horario to "public" as "Programacion";
grant update on "Programacion".horario to "public" as "Programacion";
grant insert on "Programacion".horario to "public" as "Programacion";
grant delete on "Programacion".horario to "public" as "Programacion";
grant index on "Programacion".horario to "public" as "Programacion";
grant select on "Programacion".historial to "public" as "Programacion";
grant update on "Programacion".historial to "public" as "Programacion";
grant insert on "Programacion".historial to "public" as "Programacion";
grant delete on "Programacion".historial to "public" as "Programacion";
grant index on "Programacion".historial to "public" as "Programacion";
grant select on "Programacion".dicta to "public" as "Programacion";
grant update on "Programacion".dicta to "public" as "Programacion";
grant insert on "Programacion".dicta to "public" as "Programacion";
grant delete on "Programacion".dicta to "public" as "Programacion";
grant index on "Programacion".dicta to "public" as "Programacion";
grant select on "Programacion".tiene to "public" as "Programacion";
grant update on "Programacion".tiene to "public" as "Programacion";
grant insert on "Programacion".tiene to "public" as "Programacion";
grant delete on "Programacion".tiene to "public" as "Programacion";
grant index on "Programacion".tiene to "public" as "Programacion";
grant select on "Programacion".planilla to "public" as "Programacion";
grant update on "Programacion".planilla to "public" as "Programacion";
grant insert on "Programacion".planilla to "public" as "Programacion";
grant delete on "Programacion".planilla to "public" as "Programacion";
grant index on "Programacion".planilla to "public" as "Programacion";
grant select on "Programacion".persona to "public" as "Programacion";
grant update on "Programacion".persona to "public" as "Programacion";
grant insert on "Programacion".persona to "public" as "Programacion";
grant delete on "Programacion".persona to "public" as "Programacion";
grant index on "Programacion".persona to "public" as "Programacion";
















revoke usage on language SPL from public ;

grant usage on language SPL to public ;








alter table "Programacion".grupo add constraint (foreign key 
    (cod_carrera) references "Programacion".carrera  constraint 
    "Programacion".pk_codcarretiene);
alter table "Programacion".horario add constraint (foreign key 
    (cod_turno) references "Programacion".turno  constraint "Programacion"
    .pk_codthor);
alter table "Programacion".dicta add constraint (foreign key 
    (cod_materia) references "Programacion".materia  constraint 
    "Programacion".pk_codmateriadicta);
alter table "Programacion".tiene add constraint (foreign key 
    (ci,cod_materia) references "Programacion".dicta  constraint 
    "Programacion".pk_codmateriatiene);
alter table "Programacion".tiene add constraint (foreign key 
    (cod_grupo) references "Programacion".grupo  constraint "Programacion"
    .pk_codmateriati);
alter table "Programacion".planilla add constraint (foreign key 
    (cod_grupo) references "Programacion".grupo  constraint "Programacion"
    .fk_pgrupo);
alter table "Programacion".planilla add constraint (foreign key 
    (cod_horario) references "Programacion".horario  constraint 
    "Programacion".fk_phora);
alter table "Programacion".planilla add constraint (foreign key 
    (ci,cod_materia) references "Programacion".dicta  constraint 
    "Programacion".fk);
alter table "Programacion".planilla add constraint (foreign key 
    (cod_salon) references "Programacion".salon  constraint "Programacion"
    .fk_cpsalon);







 


